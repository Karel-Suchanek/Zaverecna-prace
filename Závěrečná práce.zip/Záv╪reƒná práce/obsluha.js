let pojistenec = new Pojistenec();
pojistenec.vypisZaznamy();
