class Zaznam {
    constructor(jmeno, prijmeni, vek, telefon){
        this.jmeno = jmeno;
        this.prijmeni = prijmeni,
        this.vek = vek;
        this.telefon = telefon;
    }
}